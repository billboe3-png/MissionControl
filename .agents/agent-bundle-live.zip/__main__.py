"""Mission Control Agent - Entry point."""

import argparse
import asyncio
import sys

from agent.agent import MissionControlAgent
from agent.config import load_config
from agent.logger import setup_logging


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Mission Control Agent",
        prog="mc-agent",
    )
    parser.add_argument(
        "--server",
        type=str,
        help="Mission Control server URL",
    )
    parser.add_argument(
        "--api-key",
        type=str,
        help="API key for authentication",
    )
    parser.add_argument(
        "--agent-id",
        type=int,
        help="Agent ID (from registration)",
    )
    parser.add_argument(
        "--name",
        type=str,
        help="Agent display name",
    )
    parser.add_argument(
        "--config",
        type=str,
        help="Path to config file",
    )
    parser.add_argument(
        "--heartbeat-interval",
        type=int,
        help="Seconds between heartbeats",
    )
    parser.add_argument(
        "--no-ssl-verify",
        action="store_true",
        help="Disable SSL certificate verification",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default=None,
        help="Log level",
    )
    parser.add_argument(
        "--log-file",
        type=str,
        help="Log file path",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 1.0.0",
    )
    return parser.parse_args()


def _bootstrap_sys_path() -> None:
    """Ensure the local agent package takes precedence over any site-packages copy."""
    import sys
    from pathlib import Path
    candidates = [
        Path(__file__).resolve().parent,
        Path.cwd() / "agent",
        Path.cwd(),
    ]
    for candidate in candidates:
        candidate_str = str(candidate)
        if candidate_str not in sys.path:
            sys.path.insert(0, candidate_str)


def main() -> None:
    """Main entry point."""
    _bootstrap_sys_path()

    args = parse_args()

    config_kwargs = {}
    if args.server:
        config_kwargs["server_url"] = args.server
    if args.api_key:
        config_kwargs["api_key"] = args.api_key
    if args.agent_id:
        config_kwargs["agent_id"] = args.agent_id
    if args.name:
        config_kwargs["agent_name"] = args.name
    if args.heartbeat_interval:
        config_kwargs["heartbeat_interval"] = args.heartbeat_interval
    if args.no_ssl_verify:
        config_kwargs["verify_ssl"] = False

    config = load_config(args.config)

    for key, value in config_kwargs.items():
        if value is not None:
            setattr(config, key, value)

    setup_logging(
        level=args.log_level or config.log_level,
        log_file=args.log_file or config.log_file,
    )

    # DEBUG: log effective config values after logging is initialized
    try:
        import logging as _logging
        _logger = _logging.getLogger("mc-agent")
        effective_server = getattr(config, "server_url", "")
        effective_api_key = getattr(config, "api_key", "") or ""
        effective_agent_id = getattr(config, "agent_id", None)
        effective_log_level = getattr(config, "log_level", "")
        effective_verify_ssl = getattr(config, "verify_ssl", None)
        redacted_key = effective_api_key[:4] + "..." + effective_api_key[-4:] if len(effective_api_key) > 8 else "EMPTY"
        _logger.debug(
            "Effective config: server=%s agent_id=%s api_key=%s verify_ssl=%s log_level=%s",
            effective_server,
            effective_agent_id,
            redacted_key,
            effective_verify_ssl,
            effective_log_level,
        )
    except Exception:
        pass

    agent = MissionControlAgent(config)

    try:
        asyncio.run(agent.start())
    except KeyboardInterrupt:
        print("\nAgent shutting down...")
        asyncio.run(agent.stop())
    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
